import { db } from "./db";
import { 
  users, customers, products, quotations, quotationItems, invoices, invoiceItems, serviceCalls,
  type User, type InsertUser,
  type Customer, type InsertCustomer,
  type Product, type InsertProduct,
  type Quotation, type InsertQuotation, type QuotationItem, type InsertQuotationItem,
  type Invoice, type InsertInvoice, type InvoiceItem, type InsertInvoiceItem,
  type ServiceCall, type InsertServiceCall
} from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;

  // Customer
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer>;

  // Product
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product>;
  
  // Quotation
  getQuotations(): Promise<(Quotation & { customer: Customer })[]>;
  getQuotation(id: number): Promise<(Quotation & { items: (QuotationItem & { product: Product })[], customer: Customer }) | undefined>;
  createQuotation(quotation: InsertQuotation, items: InsertQuotationItem[]): Promise<Quotation>;
  
  // Invoice
  getInvoices(): Promise<(Invoice & { customer: Customer })[]>;
  getInvoice(id: number): Promise<(Invoice & { items: (InvoiceItem & { product: Product })[], customer: Customer }) | undefined>;
  createInvoice(invoice: InsertInvoice, items: InsertInvoiceItem[]): Promise<Invoice>;
  updateInvoice(id: number, invoice: Partial<InsertInvoice>): Promise<Invoice>;
  
  // Service Call
  getServiceCalls(): Promise<(ServiceCall & { customer: Customer, technician: User | null })[]>;
  createServiceCall(call: InsertServiceCall): Promise<ServiceCall>;
  updateServiceCall(id: number, call: Partial<InsertServiceCall>): Promise<ServiceCall>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // User
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }
  
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Customer
  async getCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer;
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db.insert(customers).values(customer).returning();
    return newCustomer;
  }

  async updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer> {
    const [updated] = await db.update(customers).set(customer).where(eq(customers.id, id)).returning();
    return updated;
  }

  // Product
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products).orderBy(products.name);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product> {
    const [updated] = await db.update(products).set(product).where(eq(products.id, id)).returning();
    return updated;
  }

  // Quotation
  async getQuotations(): Promise<(Quotation & { customer: Customer })[]> {
    return await db.query.quotations.findMany({
      with: { customer: true },
      orderBy: desc(quotations.createdAt)
    });
  }

  async getQuotation(id: number): Promise<(Quotation & { items: (QuotationItem & { product: Product })[], customer: Customer }) | undefined> {
    return await db.query.quotations.findFirst({
      where: eq(quotations.id, id),
      with: {
        customer: true,
        items: {
          with: { product: true }
        }
      }
    });
  }

  async createQuotation(quotation: InsertQuotation, items: InsertQuotationItem[]): Promise<Quotation> {
    // Generate quotation number: Q-{YEAR}-{ID}
    // Simple version: use transaction
    return await db.transaction(async (tx) => {
      // 1. Get next ID logic is tricky without explicit sequence, so we insert first with a placeholder then update?
      // Or just use timestamp-random. Let's use Q-{Date.now()}
      const quoteNum = `Q-${Date.now().toString().slice(-6)}`;
      
      const [newQuote] = await tx.insert(quotations).values({ ...quotation, quotationNumber: quoteNum }).returning();
      
      if (items.length > 0) {
        await tx.insert(quotationItems).values(
          items.map(item => ({ ...item, quotationId: newQuote.id }))
        );
      }
      
      return newQuote;
    });
  }

  // Invoice
  async getInvoices(): Promise<(Invoice & { customer: Customer })[]> {
    return await db.query.invoices.findMany({
      with: { customer: true },
      orderBy: desc(invoices.createdAt)
    });
  }

  async getInvoice(id: number): Promise<(Invoice & { items: (InvoiceItem & { product: Product })[], customer: Customer }) | undefined> {
    return await db.query.invoices.findFirst({
      where: eq(invoices.id, id),
      with: {
        customer: true,
        items: {
          with: { product: true }
        }
      }
    });
  }

  async createInvoice(invoice: InsertInvoice, items: InsertInvoiceItem[]): Promise<Invoice> {
    return await db.transaction(async (tx) => {
      const invNum = `INV-${Date.now().toString().slice(-6)}`;
      
      const [newInvoice] = await tx.insert(invoices).values({ ...invoice, invoiceNumber: invNum }).returning();
      
      if (items.length > 0) {
        await tx.insert(invoiceItems).values(
          items.map(item => ({ ...item, invoiceId: newInvoice.id }))
        );
        
        // Decrease stock
        for (const item of items) {
          // Simple stock reduction
          await tx.execute(
            sql`UPDATE products SET stock_quantity = stock_quantity - ${item.quantity} WHERE id = ${item.productId}`
          );
        }
      }
      
      return newInvoice;
    });
  }
  
  async updateInvoice(id: number, invoice: Partial<InsertInvoice>): Promise<Invoice> {
    const [updated] = await db.update(invoices).set(invoice).where(eq(invoices.id, id)).returning();
    return updated;
  }

  // Service Call
  async getServiceCalls(): Promise<(ServiceCall & { customer: Customer, technician: User | null })[]> {
    return await db.query.serviceCalls.findMany({
      with: { 
        customer: true, 
        technician: true 
      },
      orderBy: desc(serviceCalls.createdAt)
    });
  }

  async createServiceCall(call: InsertServiceCall): Promise<ServiceCall> {
    const [newCall] = await db.insert(serviceCalls).values(call).returning();
    return newCall;
  }

  async updateServiceCall(id: number, call: Partial<InsertServiceCall>): Promise<ServiceCall> {
    const [updated] = await db.update(serviceCalls).set(call).where(eq(serviceCalls.id, id)).returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
