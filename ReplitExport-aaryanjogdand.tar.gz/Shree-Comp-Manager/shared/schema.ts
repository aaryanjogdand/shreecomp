import { pgTable, text, serial, integer, boolean, timestamp, numeric, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === Users ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("staff"), // 'admin' | 'staff'
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });

// === Customers ===
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  contactPerson: text("contact_person").notNull(),
  mobile: text("mobile").notNull(),
  email: text("email"),
  address: text("address"),
  gstNumber: text("gst_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true, createdAt: true });

// === Inventory / Products ===
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand"),
  category: text("category"),
  purchasePrice: numeric("purchase_price").notNull(), // using numeric for money
  sellingPrice: numeric("selling_price").notNull(),
  stockQuantity: integer("stock_quantity").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true });

// === Quotations ===
export const quotations = pgTable("quotations", {
  id: serial("id").primaryKey(),
  quotationNumber: text("quotation_number").notNull().unique(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  date: timestamp("date").notNull(),
  totalAmount: numeric("total_amount").notNull(),
  gstAmount: numeric("gst_amount").notNull(),
  netAmount: numeric("net_amount").notNull(),
  status: text("status").default("draft"), // draft, sent, converted
  createdAt: timestamp("created_at").defaultNow(),
});

export const quotationItems = pgTable("quotation_items", {
  id: serial("id").primaryKey(),
  quotationId: integer("quotation_id").notNull().references(() => quotations.id),
  productId: integer("product_id").notNull().references(() => products.id),
  quantity: integer("quantity").notNull(),
  rate: numeric("rate").notNull(),
  amount: numeric("amount").notNull(),
});

export const insertQuotationSchema = createInsertSchema(quotations).omit({ id: true, createdAt: true, quotationNumber: true }); // number auto-generated
export const insertQuotationItemSchema = createInsertSchema(quotationItems).omit({ id: true });

// === Invoices ===
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  quotationId: integer("quotation_id").references(() => quotations.id),
  date: timestamp("date").notNull(),
  totalAmount: numeric("total_amount").notNull(),
  gstAmount: numeric("gst_amount").notNull(),
  netAmount: numeric("net_amount").notNull(),
  paidAmount: numeric("paid_amount").default("0"),
  status: text("status").default("unpaid"), // unpaid, partial, paid
  createdAt: timestamp("created_at").defaultNow(),
});

export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id),
  productId: integer("product_id").notNull().references(() => products.id),
  quantity: integer("quantity").notNull(),
  rate: numeric("rate").notNull(),
  amount: numeric("amount").notNull(),
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({ id: true, createdAt: true, invoiceNumber: true });
export const insertInvoiceItemSchema = createInsertSchema(invoiceItems).omit({ id: true });


// === Service Calls ===
export const serviceCalls = pgTable("service_calls", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  description: text("description").notNull(),
  assignedTechnicianId: integer("assigned_technician_id").references(() => users.id),
  status: text("status").default("open"), // open, in-progress, closed
  visitDate: timestamp("visit_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertServiceCallSchema = createInsertSchema(serviceCalls).omit({ id: true, createdAt: true });

// === RELATIONS ===
export const customersRelations = relations(customers, ({ many }) => ({
  quotations: many(quotations),
  invoices: many(invoices),
  serviceCalls: many(serviceCalls),
}));

export const quotationsRelations = relations(quotations, ({ one, many }) => ({
  customer: one(customers, {
    fields: [quotations.customerId],
    references: [customers.id],
  }),
  items: many(quotationItems),
}));

export const quotationItemsRelations = relations(quotationItems, ({ one }) => ({
  quotation: one(quotations, {
    fields: [quotationItems.quotationId],
    references: [quotations.id],
  }),
  product: one(products, {
    fields: [quotationItems.productId],
    references: [products.id],
  }),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  customer: one(customers, {
    fields: [invoices.customerId],
    references: [customers.id],
  }),
  quotation: one(quotations, {
    fields: [invoices.quotationId],
    references: [quotations.id],
  }),
  items: many(invoiceItems),
}));

export const invoiceItemsRelations = relations(invoiceItems, ({ one }) => ({
  invoice: one(invoices, {
    fields: [invoiceItems.invoiceId],
    references: [invoices.id],
  }),
  product: one(products, {
    fields: [invoiceItems.productId],
    references: [products.id],
  }),
}));

export const serviceCallsRelations = relations(serviceCalls, ({ one }) => ({
  customer: one(customers, {
    fields: [serviceCalls.customerId],
    references: [customers.id],
  }),
  technician: one(users, {
    fields: [serviceCalls.assignedTechnicianId],
    references: [users.id],
  }),
}));

// === TYPES ===
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Quotation = typeof quotations.$inferSelect;
export type InsertQuotation = z.infer<typeof insertQuotationSchema>;
export type QuotationItem = typeof quotationItems.$inferSelect;
export type InsertQuotationItem = z.infer<typeof insertQuotationItemSchema>;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type InsertInvoiceItem = z.infer<typeof insertInvoiceItemSchema>;

export type ServiceCall = typeof serviceCalls.$inferSelect;
export type InsertServiceCall = z.infer<typeof insertServiceCallSchema>;
