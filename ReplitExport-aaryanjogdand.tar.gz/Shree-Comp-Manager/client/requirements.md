## Packages
recharts | For dashboard analytics charts (sales, payments)
date-fns | For date formatting in tables and reports
framer-motion | For smooth page transitions and sidebar animations
react-hook-form | For complex forms (quotations, invoices)
@hookform/resolvers | Zod resolver for react-hook-form
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'Inter'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
}
