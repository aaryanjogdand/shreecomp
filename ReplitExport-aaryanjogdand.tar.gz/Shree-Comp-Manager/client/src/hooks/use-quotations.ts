import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "./use-toast";
import type { InsertQuotation, InsertQuotationItem } from "@shared/schema";

type CreateQuotationInput = InsertQuotation & { items: InsertQuotationItem[] };

export function useQuotations() {
  return useQuery({
    queryKey: [api.quotations.list.path],
    queryFn: async () => {
      const res = await fetch(api.quotations.list.path);
      if (!res.ok) throw new Error("Failed to fetch quotations");
      return api.quotations.list.responses[200].parse(await res.json());
    },
  });
}

export function useQuotation(id: number) {
  return useQuery({
    queryKey: [api.quotations.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.quotations.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch quotation");
      return api.quotations.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateQuotation() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: CreateQuotationInput) => {
      // Ensure numeric conversions for payload
      const payload = {
        ...data,
        totalAmount: String(data.totalAmount),
        gstAmount: String(data.gstAmount),
        netAmount: String(data.netAmount),
        items: data.items.map(item => ({
          ...item,
          rate: String(item.rate),
          amount: String(item.amount),
        })),
      };

      const res = await fetch(api.quotations.create.path, {
        method: api.quotations.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Failed to create quotation");
      return api.quotations.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.quotations.list.path] });
      toast({ title: "Success", description: "Quotation created successfully" });
    },
    onError: (err) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    },
  });
}
