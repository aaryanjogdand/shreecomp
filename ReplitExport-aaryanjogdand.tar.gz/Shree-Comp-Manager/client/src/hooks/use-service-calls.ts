import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "./use-toast";
import type { InsertServiceCall } from "@shared/schema";

export function useServiceCalls() {
  return useQuery({
    queryKey: [api.serviceCalls.list.path],
    queryFn: async () => {
      const res = await fetch(api.serviceCalls.list.path);
      if (!res.ok) throw new Error("Failed to fetch service calls");
      return api.serviceCalls.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateServiceCall() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertServiceCall) => {
      const res = await fetch(api.serviceCalls.create.path, {
        method: api.serviceCalls.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create service call");
      return api.serviceCalls.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.serviceCalls.list.path] });
      toast({ title: "Success", description: "Service call registered" });
    },
    onError: (err) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    },
  });
}

export function useUpdateServiceCall() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<InsertServiceCall>) => {
      const url = buildUrl(api.serviceCalls.update.path, { id });
      const res = await fetch(url, {
        method: api.serviceCalls.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update service call");
      return api.serviceCalls.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.serviceCalls.list.path] });
      toast({ title: "Success", description: "Service call updated" });
    },
    onError: (err) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    },
  });
}
