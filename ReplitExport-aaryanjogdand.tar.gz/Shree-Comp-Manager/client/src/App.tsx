import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/Sidebar";
import { Loader2 } from "lucide-react";

// Pages
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Customers from "@/pages/Customers";
import Inventory from "@/pages/Inventory";
import Quotations from "@/pages/Quotations";
import Invoices from "@/pages/Invoices";
import ServiceCalls from "@/pages/ServiceCalls";
import Team from "@/pages/Team";
import NotFound from "@/pages/not-found";

function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    setLocation("/login");
    return null;
  }

  return (
    <div className="flex h-screen bg-gray-50/50">
      <Sidebar />
      <main className="flex-1 ml-64 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function Router() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      {/* Protected Routes */}
      <Route path="/">
        <ProtectedLayout><Dashboard /></ProtectedLayout>
      </Route>
      <Route path="/customers">
        <ProtectedLayout><Customers /></ProtectedLayout>
      </Route>
      <Route path="/inventory">
        <ProtectedLayout><Inventory /></ProtectedLayout>
      </Route>
      <Route path="/quotations">
        <ProtectedLayout><Quotations /></ProtectedLayout>
      </Route>
      <Route path="/invoices">
        <ProtectedLayout><Invoices /></ProtectedLayout>
      </Route>
      <Route path="/service">
        <ProtectedLayout><ServiceCalls /></ProtectedLayout>
      </Route>
      <Route path="/team">
        <ProtectedLayout><Team /></ProtectedLayout>
      </Route>
      {/* Todo: Reports page */}
      <Route path="/reports">
         <ProtectedLayout>
           <div className="flex items-center justify-center h-[50vh] text-muted-foreground">
             Reports coming soon
           </div>
         </ProtectedLayout>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
