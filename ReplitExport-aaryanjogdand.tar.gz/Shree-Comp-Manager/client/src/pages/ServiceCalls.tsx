import { useState } from "react";
import { useServiceCalls, useCreateServiceCall, useUpdateServiceCall } from "@/hooks/use-service-calls";
import { useCustomers } from "@/hooks/use-customers";
import { useUsers } from "@/hooks/use-users";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Search, Edit2 } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import type { InsertServiceCall, ServiceCall } from "@shared/schema";

export default function ServiceCalls() {
  const { data: serviceCalls, isLoading } = useServiceCalls();
  const [search, setSearch] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCall, setEditingCall] = useState<ServiceCall | null>(null);

  const filteredCalls = serviceCalls?.filter((call) =>
    call.customer.companyName.toLowerCase().includes(search.toLowerCase()) ||
    call.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold">Service Calls</h1>
          <p className="text-muted-foreground">Manage customer complaints and visits</p>
        </div>
        <Button onClick={() => { setEditingCall(null); setIsDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Log New Call
        </Button>
      </div>

      <div className="flex items-center gap-2 max-w-sm">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search service calls..."
            className="pl-9 bg-white"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-border shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Technician</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[100px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                </TableCell>
              </TableRow>
            ) : filteredCalls?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  No service calls found
                </TableCell>
              </TableRow>
            ) : (
              filteredCalls?.map((call) => (
                <TableRow key={call.id} className="group hover:bg-muted/50">
                  <TableCell>{format(new Date(call.createdAt!), 'dd MMM yyyy')}</TableCell>
                  <TableCell className="font-medium">{call.customer.companyName}</TableCell>
                  <TableCell className="max-w-xs truncate" title={call.description}>{call.description}</TableCell>
                  <TableCell>{call.technician?.name || "Unassigned"}</TableCell>
                  <TableCell>
                    <StatusBadge status={call.status || "open"} />
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setEditingCall(call);
                        setIsDialogOpen(true);
                      }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Edit2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <ServiceCallDialog 
        open={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
        serviceCall={editingCall} 
      />
    </div>
  );
}

function ServiceCallDialog({ open, onOpenChange, serviceCall }: { open: boolean, onOpenChange: (open: boolean) => void, serviceCall: ServiceCall | null }) {
  const createMutation = useCreateServiceCall();
  const updateMutation = useUpdateServiceCall();
  const { data: customers } = useCustomers();
  const { data: users } = useUsers();
  
  const technicians = users?.filter(u => u.role === "staff") || [];

  const [customerId, setCustomerId] = useState(serviceCall?.customerId?.toString() || "");
  const [description, setDescription] = useState(serviceCall?.description || "");
  const [technicianId, setTechnicianId] = useState(serviceCall?.assignedTechnicianId?.toString() || "");
  const [status, setStatus] = useState(serviceCall?.status || "open");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data: any = {
      customerId: parseInt(customerId),
      description,
      status,
      assignedTechnicianId: technicianId ? parseInt(technicianId) : null,
    };

    if (serviceCall) {
      await updateMutation.mutateAsync({ id: serviceCall.id, ...data });
    } else {
      await createMutation.mutateAsync(data);
    }
    onOpenChange(false);
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{serviceCall ? "Update Service Call" : "Log New Service Call"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Customer</Label>
            <Select value={customerId} onValueChange={setCustomerId} disabled={!!serviceCall}>
              <SelectTrigger>
                <SelectValue placeholder="Select Customer" />
              </SelectTrigger>
              <SelectContent>
                {customers?.map(c => (
                  <SelectItem key={c.id} value={c.id.toString()}>{c.companyName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea 
              value={description} 
              onChange={(e) => setDescription(e.target.value)} 
              placeholder="Describe the issue..."
              rows={4}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Assign Technician</Label>
              <Select value={technicianId} onValueChange={setTechnicianId}>
                <SelectTrigger>
                  <SelectValue placeholder="Unassigned" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Unassigned</SelectItem>
                  {technicians.map(t => (
                    <SelectItem key={t.id} value={t.id.toString()}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={isPending}>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {serviceCall ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
