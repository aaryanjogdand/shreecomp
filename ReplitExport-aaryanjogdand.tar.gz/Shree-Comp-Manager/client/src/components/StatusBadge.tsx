import { cn } from "@/lib/utils";

type StatusType = "open" | "in-progress" | "closed" | "paid" | "unpaid" | "partial" | "draft" | "sent" | "converted";

interface StatusBadgeProps {
  status: StatusType | string;
  className?: string;
}

const statusStyles: Record<string, string> = {
  // Service
  open: "bg-red-100 text-red-700 border-red-200",
  "in-progress": "bg-amber-100 text-amber-700 border-amber-200",
  closed: "bg-green-100 text-green-700 border-green-200",
  
  // Invoice
  paid: "bg-emerald-100 text-emerald-700 border-emerald-200",
  unpaid: "bg-rose-100 text-rose-700 border-rose-200",
  partial: "bg-blue-100 text-blue-700 border-blue-200",
  
  // Quotation
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  sent: "bg-indigo-100 text-indigo-700 border-indigo-200",
  converted: "bg-purple-100 text-purple-700 border-purple-200",
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const normalizedStatus = status.toLowerCase();
  const styles = statusStyles[normalizedStatus] || "bg-gray-100 text-gray-700 border-gray-200";

  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border capitalize",
      styles,
      className
    )}>
      {status.replace("-", " ")}
    </span>
  );
}
